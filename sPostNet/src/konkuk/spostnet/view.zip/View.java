package konkuk.spostnet.view;

import konkuk.spostnet.model.Employee;

public interface View {

	public void setModel(Object model);
	public void viewInvoker();
}
