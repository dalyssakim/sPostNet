package konkuk.spostnet.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.lang.instrument.ClassFileTransformer;

import konkuk.spostnet.model.Employee;

public class WarehouseMangerView extends JFrame {

	private JPanel contentPane;
	private Employee employee = null; 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WarehouseMangerView frame = new WarehouseMangerView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void setEmployee(Employee employee){
		this.employee = employee;
	}
	/**
	 * Create the frame.
	 */
	public WarehouseMangerView() {
		// public WarehouseManagerView(Employee emp) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 355, 262);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		JLabel lblId = new JLabel("[Name]");
		// JLabel lblId = new JLabel("[Name] "+emp.getName());
		lblId.setBounds(24, 21, 117, 15);
		panel.add(lblId);

		JLabel lblRole = new JLabel("[Role]");
		// JLabel lblRole = new JLabel("[Role] "+emp.getRole());
		lblRole.setBounds(24, 46, 57, 15);
		panel.add(lblRole);

		JLabel lblCenterid = new JLabel("[CenterId]");
		// JLabel lblCenterid = new JLabel("[CenterId] "+emp.getCenterId());
		lblCenterid.setBounds(24, 71, 134, 15);
		panel.add(lblCenterid);

		JButton btnNewButton = new JButton("Classify Item");
		btnNewButton.setBounds(12, 164, 148, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClassificationView cfv = new ClassificationView();
				cfv.setVisible(true);
			}
		});

		panel.add(btnNewButton);

		JButton btnSignout = new JButton("Sign-out");
		btnSignout.setBounds(169, 164, 148, 23);
		panel.add(btnSignout);
		btnSignout.addActionListener(new ActionListener (){
			public void actionPerformed(ActionEvent e){
				dispose();
			}
		});

	}
}
