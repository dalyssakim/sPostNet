package konkuk.spostnet.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;


public class TransactionView extends JFrame {

	private String[] priority = {"High", "Low"};
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	
	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public TransactionView() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 493, 301);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblItemId = new JLabel("Sender Name");
		lblItemId.setBounds(12, 31, 86, 15);
		panel.add(lblItemId);
		
		JLabel lblNewLabel_1 = new JLabel("Sender Address");
		lblNewLabel_1.setBounds(12, 59, 107, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Sender PhoneNum");
		lblNewLabel.setBounds(12, 89, 107, 15);
		panel.add(lblNewLabel);
		
		JLabel lblWeight = new JLabel("Weight");
		lblWeight.setBounds(278, 130, 57, 15);
		panel.add(lblWeight);
		
		JLabel lblPriority = new JLabel("Priority");
		lblPriority.setBounds(278, 162, 57, 15);
		panel.add(lblPriority);
		
		JLabel lblNewLabel_2 = new JLabel("Receiver Name");
		lblNewLabel_2.setBounds(12, 130, 100, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Reciever Address");
		lblNewLabel_3.setBounds(12, 162, 107, 15);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Receiver PhoneNum");
		lblNewLabel_4.setBounds(12, 193, 116, 15);
		panel.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(138, 28, 116, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(138, 86, 116, 21);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(138, 56, 116, 21);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(328, 127, 100, 21);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(138, 127, 116, 21);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(138, 159, 116, 21);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(138, 190, 116, 21);
		panel.add(textField_6);
		textField_6.setColumns(10);
		
		JComboBox comboBox_1 = new JComboBox(priority);
		comboBox_1.setBounds(328, 159, 68, 21);
		panel.add(comboBox_1);

		
		JButton btnRegister = new JButton("Register");
		btnRegister.setBounds(257, 220, 97, 23);
		panel.add(btnRegister);
		btnRegister.addActionListener(new ActionListener (){
			public void actionPerformed(ActionEvent e){
				/*
				 * Register on database.
				 * */
			}
		});
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(357, 220, 97, 23);
		panel.add(btnCancel);
		btnCancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
			}
		});
		
	
	}
}
